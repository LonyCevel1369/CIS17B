# To Do:

Map drawing
* Function to take map data and split out HTML
* All map tiles should be in one large `<div>`

Collision Detection / Physics
* Check if two bounding boxes have a collision

Animations
* An animation system so that we can do something like:
* `entity.anim.play("Walk");`

Enemies
Attacking
Inventory
Heads Up Display
Save/Loading
Multiplayer